// Petit serveur de compilation pour l'extension "Arduino Mini-IDE".
// Reçoit du code de sketch + un FQBN, appelle arduino-cli, renvoie le .hex compilé.
//
// ATTENTION : ce serveur exécute un compilateur sur du texte envoyé par le client.
// Il est prévu pour un usage interne (salle de classe / réseau de confiance), pas pour
// être exposé publiquement sans authentification supplémentaire — voir le README.

const express = require("express");
const cors = require("cors");
const { exec } = require("child_process");
const fs = require("fs/promises");
const path = require("path");
const os = require("os");

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));

const PORT = process.env.PORT || 8080;
const COMPILE_TIMEOUT_MS = 30000;

function run(cmd, opts) {
  return new Promise((resolve) => {
    exec(cmd, { timeout: COMPILE_TIMEOUT_MS, maxBuffer: 10 * 1024 * 1024, ...opts }, (error, stdout, stderr) => {
      resolve({ error, stdout, stderr });
    });
  });
}

app.get("/health", (req, res) => res.json({ ok: true }));

app.post("/compile", async (req, res) => {
  const { sketch, fqbn } = req.body || {};
  if (typeof sketch !== "string" || !sketch.trim()) {
    return res.status(400).json({ error: "Champ 'sketch' manquant ou vide." });
  }
  if (typeof fqbn !== "string" || !fqbn.trim()) {
    return res.status(400).json({ error: "Champ 'fqbn' manquant (ex: arduino:avr:uno)." });
  }

  const workDir = await fs.mkdtemp(path.join(os.tmpdir(), "sketch-"));
  const sketchName = "sketch";
  const sketchDir = path.join(workDir, sketchName);
  await fs.mkdir(sketchDir);
  const inoPath = path.join(sketchDir, sketchName + ".ino");
  await fs.writeFile(inoPath, sketch, "utf8");

  const outDir = path.join(workDir, "build");
  await fs.mkdir(outDir);

  const cmd = [
    "arduino-cli", "compile",
    "--fqbn", JSON.stringify(fqbn).replace(/"/g, ""),
    "--output-dir", outDir,
    sketchDir
  ].join(" ");

  const { error, stdout, stderr } = await run(cmd);

  if (error) {
    await fs.rm(workDir, { recursive: true, force: true }).catch(() => {});
    return res.status(400).json({
      error: "La compilation a échoué.",
      stdout,
      stderr
    });
  }

  try {
    const files = await fs.readdir(outDir);
    const hexFile = files.find((f) => f.endsWith(".hex"));
    if (!hexFile) {
      return res.status(500).json({ error: "Compilation réussie mais aucun .hex généré.", stdout, stderr });
    }
    const hexText = await fs.readFile(path.join(outDir, hexFile), "utf8");
    res.json({ hex: hexText, stdout, stderr });
  } catch (e) {
    res.status(500).json({ error: "Erreur de lecture du .hex : " + e.message, stdout, stderr });
  } finally {
    await fs.rm(workDir, { recursive: true, force: true }).catch(() => {});
  }
});

app.listen(PORT, () => {
  console.log("Serveur de compilation Arduino sur le port " + PORT);
});
